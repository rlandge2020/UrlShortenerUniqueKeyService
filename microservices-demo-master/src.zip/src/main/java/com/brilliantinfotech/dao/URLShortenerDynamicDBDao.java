package com.brilliantinfotech.dao;

import com.brilliantinfotech.utility.UniqueKeyResponse;

/**
 * 
 * @author Rahul Landge
 *
 */
public interface URLShortenerDynamicDBDao {
	/**
	 * 
	 * @return
	 */

	public UniqueKeyResponse getUniqueKey();

	public UniqueKeyResponse createKeys(int numberOfKeys);

	public UniqueKeyResponse deleteKey(String key);

}
